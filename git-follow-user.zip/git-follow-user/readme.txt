Simple React App

The Users who have forked the repo Facebook/react is shown and with your github credentials(comming through Token) you can follow the user


Steps to run The app

(IMPORTANTLY) Add you github token in .env file 
i.e, 
REACT_APP_API_KEY = <ADD_YOUR_GITHUB_APITOKEN>

Replace 
<ADD_YOUR_GITHUB_APITOKEN> 
with you github token generated from your account



1. npm install (or) yarn install
2. npm start   (or) yarn start
3. open localhost:3000 in browser, incase it doesnot start automatically