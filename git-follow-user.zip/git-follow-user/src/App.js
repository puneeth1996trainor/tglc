import React, { Component } from 'react';
import { Card, CardColumns  } from 'react-bootstrap';
import 'dotenv'

export default class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      forksCount: 0,
      users: [],
      following: [],
      totalPage: 0,
      perPage: 20,
      currentPage: 1,
    };
    this.receivedData = this.receivedData.bind(this);
  }
  receivedData = (pageNum) => {
    fetch(`https://api.github.com/repos/facebook/react/forks?per_page=${this.state.perPage}&page=${pageNum}`)
    .then(res => res.json())
    .then((data) => {
      this.setState({ users: data })
    })
    .catch(console.log)
  }
  prevPageFunc = () => {
    if(this.state.currentPage > 1){
      this.receivedData(this.state.currentPage - 1);
      this.setState({
        currentPage: this.state.currentPage - 1
      });
    }
  }
  nextPageFunc = () => {
    this.receivedData(this.state.currentPage + 1);
    this.setState({
      currentPage: this.state.currentPage + 1
    });
  }
  componentDidMount() {
    const perPageVal = this.state.perPage;
    fetch('https://api.github.com/repos/facebook/react')
    .then(res => res.json())
    .then((data) => {
      this.setState({ forksCount: data.forks, totalPage: Math.floor(data.forks/perPageVal) })
    })
    .catch(console.log);
    this.receivedData(this.state.currentPage);
  }
  followUser = user => {
    fetch( ('https://api.github.com/user/following/' + user.owner.login) ,  { 
      method: 'PUT', 
      headers: {
        'Authorization': 'Token '+ process.env.REACT_APP_API_KEY, 
        'Content-Length': '0'
      }
    }).then(resp => {
      if(resp.status === 204){
        alert( "You Have Started Following: " + ( resp.url.replace('https://api.github.com/user/following/','') ) )
      } 
    })
    .catch(console.log);
  }
  render() {
    const divStyle = {
      margin: '5vh 0vw 3vh 30vw',
    };
    const h1Style = {
      marginTop: '20vh',
      marginLeft: '15vw',
      marginBottom: '15vh',
    };
    const lStyle = {
      marginLeft: '200px',
    };
    return (
      <>
        <h4   style={h1Style} >The Total Number Of Forks are {this.state.forksCount}, per page profile showing {this.state.perPage}.</h4>
        <div> <span  onClick={this.prevPageFunc}>Prev Result</span> <b> {this.state.currentPage} </b> <span  onClick={this.nextPageFunc}>Next Result</span> </div>
        <CardColumns>
          {
            (this.state.users.length > 1) ? 
            this.state.users.map((user) =>  
              <Card   style={divStyle} key={user.node_id}>
                <Card.Img variant="top" src={user.owner.avatar_url} />
                <Card.Title>{user.full_name}</Card.Title>
                <Card.Body>
                  <Card.Link    style={lStyle} href={user.owner.html_url}>Profile</Card.Link>
                </Card.Body>
                <Card.Body>
                  <Card.Link    style={lStyle} onClick={() => this.followUser(user)} >Follow</Card.Link>
                </Card.Body>
              </Card>
            ) : 
            <h1>No Results</h1>
          }
        </CardColumns>
      </>
    )
  }
}
